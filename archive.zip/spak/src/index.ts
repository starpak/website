// ===== Spak — unified facade entry point =====
//
// This package ("spak") is the monorepo root package published to npm.
// Its ONLY job is to re-export the core public API so end users can write:
//
//   import { Context, h, t, createApp, Loader } from 'spak'
//
// instead of importing half a dozen @spakjs/* packages by hand.
//
// It MUST NOT implement any new logic itself — only re-export and glue.
// If you find yourself adding feature code here, stop and think about
// which @spakjs/* sub-package it really belongs in.

export * from '@spakjs/core'
export * from '@spakjs/message'
export * from '@spakjs/util'
export * from '@spakjs/i18n'
export * as Config from '@spakjs/config'
export { default as Loader } from '@spakjs/loader'
export * from '@spakjs/loader'

// Convenience: also re-export CLI command helpers for plugin devs that want
// to register their own subcommands programmatically.
export type {
  CommandDeclaration,
  CommandArg,
  CommandOption,
} from '@spakjs/util'

import type NodeLoader from '@spakjs/loader'
import { init as initI18n, setLanguage } from '@spakjs/i18n'

export interface CreateAppOptions {
  /** Path to a spak.config.* file.  Absolute or relative to CWD. */
  config?: string
  /** Initial language override for the i18n system (e.g. 'zh', 'en'). */
  language?: string
  /** Shortcut: set `process.env.SPAK_HOST` / `SPAK_PORT` for plugin-server. */
  host?: string
  port?: string | number
  /** Extra env vars merged into process.env before loader init. */
  env?: Record<string, string>
}

/**
 * One-line convenience for most applications: read config, create the
 * application, wire i18n, optionally apply host/port overrides, and
 * return the ready-to-start Context.
 *
 * ```ts
 * import { createApp } from 'spak'
 * const app = await createApp({ language: 'zh', port: 5000 })
 * await app.start()
 * ```
 */
export async function createApp(options: CreateAppOptions = {}): Promise<any> {
  const { config, language, host, port, env } = options
  if (env) Object.assign(process.env, env)
  if (host) process.env.SPAK_HOST = host
  if (port) process.env.SPAK_PORT = String(port)

  const { default: NodeLoader } = (await import('@spakjs/loader')) as {
    default: new () => NodeLoader
  }
  const loader: any = new NodeLoader()
  await loader.init(config)
  await loader.readConfig(true)

  if (language) setLanguage(language)

  const app = await loader.createApp()
  // wire the i18n helper so plugins can `import { T } from 'spak'` and get the
  // same instance core uses
  if (app.i18n) initI18n(app.i18n)

  return app
}

export default { createApp }
