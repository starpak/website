# S̷p̷a̷k̷ ✨(=ↀωↀ=)✧

> ̷̷M̷e̷o̷w̷~ A multi-file service framework built on Koishi, said the cat!

> **Humans**: [README.md](README.md) | **Earth Chinese**: [README.zh.md](README.zh.md)

---

## (=ↀωↀ=) Whisker What?

**S̷p̷a̷k̷** is a **multi-file service framework** purched on top of [Koishi](https://koishi.chat/). It lets you organize plugin apps with built-in purrs for config, i18n, CLI, and service meow-chestration.

S̷p̷a̷k̷ uses **TypeScript** with a **pnpm monorepo** archite-cat-ure.

---

## Cat-tastic Packages

| Package | What it does |
|---------|-------------|
| `@spakjs/core` 🧠 | The brain! Meowmands, middle-cat, i18n, purrmissions |
| `@spakjs/cli` 🎮 | CLI kitty: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Config feeder, eats YAML/JSON, nom nom env |
| `@spakjs/config` ⚙️ | Config scratcher, keeps in `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | Trans-cat-ion system with yml files |
| `@spakjs/ccmd` ⌨️ | Config paw-sitions: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: catbox, purr-monitoring, plugin check |
| `@spakjs/usefor` 🧰 | Utility claws: observe, string interpawlation |
| `@spakjs/i18n-utils` 🌍 | Locale tree and furball fallback |

## Meow-dules (Plugins)

| Plugin | What it does |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | Server purrvice and routing |
| `@spakjs/plugin-http` 🌐 | HTTP and WebSocket cat-client |
| `@spakjs/plugin-hmr` 🔥 | Hot Meowdule Replacement |
| `@spakjs/plugin-daemon` 👻 | Background cat-daemon |

---

## Quick Paw-start

### Claw-requirements

- Node.js >= 18
- pnpm >= 10

### Cat-setup

```bash
pnpm install
pnpm build
```

### Cat-figuration

Create **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Purr-run!

```bash
spak serve
spak serve ./spak.config.yml
```

### Cat CLI commands

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Cat-docs

| Language | File |
|----------|------|
| 👽 Human English | [README.md](README.md) |
| 🌏 Earth Chinese | [README.zh.md](README.zh.md) |

---

## Purr-mit

MIT License. Copyright © Spak Team

(=ↀωↀ=)✧ Meow~ If you want to add new features or fix bugs, this cat is always here to help! (=ↀωↀ=)✧
