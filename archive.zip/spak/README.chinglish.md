# Spak 框架 ✨

> A 基于 Koishi 的 multi-file service project framework

> **正宗英文**: [README.md](README.md) | **纯正中文**: [README.zh.md](README.zh.md)

---

## What is Spak 的说？

**Spak** 是一个 **multi-file service project framework**，built on top of [Koishi](https://koishi.chat/)。It 提供了 a structured way to organize 插件-based applications，with built-in support for 配置管理、国际化、CLI 工具和 service orchestration。

Spak 使用 **TypeScript** with **pnpm monorepo** 架构，very 强大！

---

## Packages 一览

| Package | 功能 Description |
|---------|----------------|
| `@spakjs/core` 🧠 | Core 核心：commands、middleware、i18n、permissions、schemas，very 重要 |
| `@spakjs/cli` 🎮 | CLI 入口 point：`spak serve`、`spak config`、`spak cpc` |
| `@spakjs/loader` 📂 | Config 加载器，support YAML/JSON，handle env files |
| `@spakjs/config` ⚙️ | 配置管理 central，save 到 `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | 翻译 System based on yml files，can 国际化 |
| `@spakjs/ccmd` ⌨️ | 配置 Commands：`config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC：sandbox、监控、plugin check，very 安全 |
| `@spakjs/usefor` 🧰 | 工具 Functions：observe、string interpolation |
| `@spakjs/i18n-utils` 🌍 | Locale tree and fallback 工具 |

## Plugins

| Plugin | Description |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | 服务器 Service and 路由 routing |
| `@spakjs/plugin-http` 🌐 | HTTP 和 WebSocket 客户端 client |
| `@spakjs/plugin-hmr` 🔥 | 热模块替换 Hot Module Replacement |
| `@spakjs/plugin-daemon` 👻 | 后台守护 Background daemon |

---

## Quick Start 快速开始

### 需要准备 Prerequisites

- Node.js >= 18
- pnpm >= 10

### 安装 Setup

```bash
pnpm install
pnpm build
```

### 配置 Configuration

Create **spak.config.yml**：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 启动 Run

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI 命令 Commands

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 文档 Documentation

| Language | File |
|----------|------|
| 🏴󠁧󠁢󠁥󠁮󠁧󠁿 English | [README.md](README.md) |
| 🇨🇳 Chinese | [README.zh.md](README.zh.md) |

---

## 许可证 License

MIT License. Copyright © Spak Team

这个框架很 good，你值得 have！(>ω<)ﾉ☆
