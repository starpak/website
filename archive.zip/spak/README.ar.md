# سباك ✨

> إطار عمل للمشاريع متعددة الخدمات مبني على Koishi

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## ما هو سباك؟

**سباك** هو **إطار عمل للمشاريع متعددة الخدمات** مبني على [Koishi](https://koishi.chat/). يوفر طريقة منظمة لتنظيم التطبيقات القائمة على الإضافات مع دعم مدمج لإدارة التكوين، التدويل، أدوات سطر الأوامر، وتنسيق الخدمات.

يستخدم سباك **TypeScript** مع بنية **pnpm monorepo**.

---

## الحزم

| الحزمة | الوصف |
|--------|-------|
| `@spakjs/core` 🧠 | النواة: الأوامر، الوسيط، i18n، الصلاحيات، المخططات |
| `@spakjs/cli` 🎮 | واجهة CLI: `spak serve`، `spak config`، `spak cpc` |
| `@spakjs/loader` 📂 | محمل التكوين، يدعم YAML/JSON وملفات البيئة |
| `@spakjs/config` ⚙️ | مدير التكوين المركزي، يحفظ في `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | نظام ترجمة يعتمد على ملفات yml |
| `@spakjs/ccmd` ⌨️ | أوامر التكوين: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: صندوق حماية، مراقبة، فحص الإضافات |
| `@spakjs/usefor` 🧰 | دوال مساعدة: مراقبة، استيفاء النصوص |
| `@spakjs/i18n-utils` 🌍 | شجرة اللغات وأدوات الاسترجاع |

## الإضافات

| الإضافة | الوصف |
|---------|-------|
| `@spakjs/plugin-server` 🖥️ | خدمة الخادم والتوجيه |
| `@spakjs/plugin-http` 🌐 | عميل HTTP و WebSocket |
| `@spakjs/plugin-hmr` 🔥 | الاستبدال السريع للوحدات |
| `@spakjs/plugin-daemon` 👻 | خفيّة الخلفية |

---

## بداية سريعة

### المتطلبات

- Node.js >= 18
- pnpm >= 10

### التثبيت

```bash
pnpm install
pnpm build
```

### الإعداد

أنشئ **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### التشغيل

```bash
spak serve
spak serve ./spak.config.yml
```

### أوامر CLI

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 الوثائق

- [English](README.md)
- [中文](README.zh.md)

---

## الترخيص

MIT License. Copyright © Spak Team
