# Spak ✨ — 天地之道，万物之序

> 夫 Koishi 者，大道之源也；Spak 承其道而化用之，以理万务。

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## 第一章：道可道，非常道

**Spak** 者，**多务一统之框架**也。以 [Koishi](https://koishi.chat/) 为基，承其血脉，开其疆域。插件为体，配置为用，命令为器，服务为术——四者合一，乃成其大。

《易》曰："形而上者谓之道，形而下者谓之器。" Spak 兼得之。道者，插件之体系也；器者，CLI 之具象也。

Spak 用 **TypeScript** 为言，以 **pnpm monorepo** 为构，此乃当世之正法也。

---

## 第二章：格物致知——包络万象

| 包名 | 其用 |
|------|------|
| `@spakjs/core` 🧠 | 心之官则思。命令、中介、i18n、权柄、范式，皆统于此 |
| `@spakjs/cli` 🎮 | 门也。`spak serve`、`spak config`、`spak cpc` 引君入室 |
| `@spakjs/loader` 📂 | 食也。吞 YAML/JSON 以养其身，env 为佐 |
| `@spakjs/config` ⚙️ | 仓禀也。藏 `~/.spak/config.json`，取用不竭 |
| `@spakjs/locales` 🌐 | 译也。yml 为媒，通四海之语 |
| `@spakjs/ccmd` ⌨️ | 令也。`config get/set/list` 为其号令 |
| `@spakjs/cpc` 🔒 | 卫也。沙箱以护，监控以察，检插件以正 |
| `@spakjs/usefor` 🧰 | 器也。观物、缀文、杂用，皆备于此 |
| `@spakjs/i18n-utils` 🌍 | 度也。locale 之树，fallback 之策 |

## 第三章：插件即佛，佛即插件

| 插件 | 其义 |
|------|------|
| `@spakjs/plugin-server` 🖥️ | 务也。路由四方，接引八面 |
| `@spakjs/plugin-http` 🌐 | 通也。HTTP 与 WebSocket，天下一家 |
| `@spakjs/plugin-hmr` 🔥 | 易也。热更而不重启，变通之道也 |
| `@spakjs/plugin-daemon` 👻 | 默也。幕后行事，不为外人道也 |

---

## 第四章：知行合一——快速入门

### 天时地利

- Node.js >= 18
- pnpm >= 10

### 种因得果

```bash
pnpm install   # 播其种
pnpm build     # 收其果
```

### 立规矩，成方圆

**spak.config.yml** 者，法度之书也：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 道生一，一生二

```bash
spak serve              # 道之始也
spak serve ./spak.config.yml  # 以法为凭
```

### 号令三军

```bash
spak config get <key>   # 问政于君
spak config set <key> <value>  # 变法于民
spak config list        # 览天下之状
spak cpc check          # 察百官之忠
spak cpc status         # 观四海之安
```

---

## 第五章：万法归宗

诸子百家，殊途同归。Spak 之道，在于简而不陋，繁而不乱。

| 语言文字 | 经典 |
|----------|------|
| 🇬🇧 English | [README.md](README.md) |
| 🇨🇳 简体中文 | [README.zh.md](README.zh.md) |

---

## 许可证

MIT License。Copyright © Spak Team

> 天行健，君子以自强不息。Spak 之道，与时偕行。
