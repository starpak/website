# 斯巴克記 ✨

> 夫 Koishi 之器，化而爲斯巴克，以御多務之器也。

> **English**: [README.md](README.md) | **简体中文**: [README.zh.md](README.zh.md)

---

## 斯巴克者何也

**斯巴克**者，**務器之統綱**也。以 [Koishi](https://koishi.chat/) 爲基，拓其疆宇。插件以爲體，配置以爲用，命行以爲器，諸務以爲術——四者備，而後大成。

斯巴克用 **TypeScript** 爲文，以 **pnpm monorepo** 爲構，蓋當世之良法也。

---

## 諸包列傳

| 包名 | 職司 |
|------|------|
| `@spakjs/core` 🧠 | 心腹也。命行、中道、譯事、權柄、範式，皆繫於此 |
| `@spakjs/cli` 🎮 | 門戶也。令曰 `spak serve`、`spak config`、`spak cpc` |
| `@spakjs/loader` 📂 | 庖廚也。納 YAML/JSON 以養焉，env 爲佐 |
| `@spakjs/config` ⚙️ | 府庫也。藏於 `~/.spak/config.json`，取用不竭 |
| `@spakjs/locales' 🌐 | 譯者。yml 爲媒，通八荒之言 |
| `@spakjs/ccmd` ⌨️ | 命司也。掌 `config get/set/list` 之令 |
| `@spakjs/cpc` 🔒 | 衛尉也。沙箱以護，監察以明，檢插件以正 |
| `@spakjs/usefor` 🧰 | 匠作也。觀物、綴辭諸器，皆備於此 |
| `@spakjs/i18n-utils' 🌍 | 度支也。locale 之樹，fallback 之策，譯事賴之 |

## 諸插件列傳

| 插件 | 職司 |
|------|------|
| `@spakjs/plugin-server` 🖥️ | 驛丞。迎送四方，接引八面 |
| `@spakjs/plugin-http' 🌐 | 行人。HTTP 與 WebSocket，通天下之有無 |
| `@spakjs/plugin-hmr` 🔥 | 更人。熱替而不重啟，善變者也 |
| `@spakjs/plugin-daemon` 👻 | 陰士。潛行於幕後，不爲人所知 |

---

## 速成篇

### 器用之備

- Node.js >= 18
- pnpm >= 10

### 立基

```bash
pnpm install   # 播種
pnpm build     # 收穫
```

### 設綱紀

**spak.config.yml** 者，法度之典也：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 行令

```bash
spak serve              # 始行
spak serve ./spak.config.yml  # 依法而行
```

### 號令

```bash
spak config get <key>   # 問政
spak config set <key> <value>  # 變法
spak config list        # 覽狀
spak cpc check          # 察忠奸
spak cpc status         # 觀世態
```

---

## 📖 諸國文

| 言語 | 文檔 |
|------|------|
| 🇬🇧 English | [README.md](README.md) |
| 🇨🇳 简体中文 | [README.zh.md](README.zh.md) |

---

## 許可

MIT License。Copyright © Spak Team

> 嗟乎！斯巴克之道，簡而不陋，繁而不亂，誠良器也。
