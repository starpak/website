# Spak ✨

> Ein Multi-Datei-Service-Projekt-Framework basierend auf Koishi

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Was ist Spak?

**Spak** ist ein **Multi-Datei-Service-Projekt-Framework**, das auf [Koishi](https://koishi.chat/) aufbaut. Es bietet eine strukturierte Möglichkeit, plugin-basierte Anwendungen zu organisieren, mit integrierter Unterstützung für Konfigurationsverwaltung, Internationalisierung, CLI-Tools und Service-Orchestrierung.

Spak verwendet **TypeScript** mit einer **pnpm monorepo**-Architektur.

---

## Pakete

| Paket | Beschreibung |
|-------|-------------|
| `@spakjs/core` 🧠 | Kern: Befehle, Middleware, i18n, Berechtigungen, Schemata |
| `@spakjs/cli` 🎮 | CLI-Einstieg: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Konfigurationslader, unterstützt YAML/JSON, env-Dateien |
| `@spakjs/config` ⚙️ | Zentraler Konfigurationsmanager, speichert in `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | Übersetzungssystem mit yml-basierten Lokalisierungsdateien |
| `@spakjs/ccmd` ⌨️ | Konfigurationsbefehle: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: Sandbox, Überwachung, Plugin-Prüfung |
| `@spakjs/usefor` 🧰 | Hilfsfunktionen: Beobachtung, String-Interpolation |
| `@spakjs/i18n-utils` 🌍 | Locale-Baum und Fallback-Hilfsprogramme |

## Plugins

| Plugin | Beschreibung |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | Serverdienst und Routing |
| `@spakjs/plugin-http` 🌐 | HTTP- und WebSocket-Client |
| `@spakjs/plugin-hmr` 🔥 | Hot Module Replacement |
| `@spakjs/plugin-daemon` 👻 | Hintergrund-Daemon |

---

## Schnellstart

### Voraussetzungen

- Node.js >= 18
- pnpm >= 10

### Einrichtung

```bash
pnpm install
pnpm build
```

### Konfiguration

Erstellen Sie **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Start

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI-Befehle

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Dokumentation

- [English](README.md)
- [中文](README.zh.md)

---

## Lizenz

MIT License. Copyright © Spak Team
