# Spak 变更日志喵～ ✨

> 咱记录下每次长大的足迹的说！(｡>ω<｡)

---

## [0.0.3] — 2026-07-25 🐱

### ✨ 新功能
- 初始化项目基础结构的说！
- 核心包 `@spakjs/core` 搭建完成喵～
- CLI 工具 `@spakjs/cli` 可以跑起来啦！
- 配置加载器 `@spakjs/loader` 支持 YAML/JSON 读取的说
- 工具包 `@spakjs/utils` 装了好多小玩意喵
- 国际化工具 `@spakjs/i18n-utils` 准备就绪～

### 🖥️ 插件
- `@spakjs/plugin-server` 服务器服务插件
- `@spakjs/plugin-http` HTTP 相关插件
- `@spakjs/plugin-hmr` 热更新插件
- `@spakjs/plugin-common` 通用插件合集

### 🏗️ 工程化
- 采用 pnpm monorepo 架构的说
- TypeScript 严格模式配置
- MIT 开源许可证
- 喵娘风格的 README 上线啦！

---

> 呜喵～之前的版本咱还没来得及记录的说～下次一定补上！(*>ω<*)ﾉ
