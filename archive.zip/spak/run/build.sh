#!/usr/bin/env bash
#
# Spak Build Script
# 构建所有 TypeScript 包，并尝试注册全局命令
#

set -e

# Colors
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_LOG="$PROJECT_ROOT/.build.log"
SPAK_VERSION=$(node -e "console.log(require('$PROJECT_ROOT/package.json').version)")

echo ""
echo -e "  ${CYAN}◇${NC}  ${BOLD}Spak Build${NC} ${DIM}v${SPAK_VERSION}${NC}"
echo ""

# Step 1: TypeScript Compilation
echo -e "  ${CYAN}◇${NC}  Compiling TypeScript..."

if pnpm tsc --build --force > "$BUILD_LOG" 2>&1; then
  echo -e "  ${GREEN}✓${NC}  TypeScript compilation successful"
else
  echo -e "  ${RED}✗${NC}  TypeScript compilation failed"
  cat "$BUILD_LOG"
  rm -f "$BUILD_LOG"
  exit 1
fi

rm -f "$BUILD_LOG"

# Step 1.5: Copy locale files for core package
LOCALES_SRC="$PROJECT_ROOT/packages/core/src/locales"
LOCALES_DST="$PROJECT_ROOT/packages/core/lib/locales"
if [ -d "$LOCALES_SRC" ]; then
  mkdir -p "$LOCALES_DST"
  cp "$LOCALES_SRC"/*.yml "$LOCALES_DST" 2>/dev/null || true
fi

# Step 2: Global binary registration
echo ""
echo -e "  ${CYAN}◇${NC}  Registering spak command..."

BIN_SOURCE="$PROJECT_ROOT/packages/spak-cli/bin.js"
BIN_TARGET="/usr/local/bin/spak"

# Check if we're in a virtual/container environment
IN_VENV=false
if [ ! -w "/usr/local/bin" ] || [ -n "$CI" ] || [ -n "$CONTAINER" ] || [ -f "/.dockerenv" ]; then
  IN_VENV=true
fi

if [ "$IN_VENV" = true ]; then
  # Virtual environment: copy to build output instead
  BUILD_OUTPUT="$PROJECT_ROOT/dist/spak"
  mkdir -p "$PROJECT_ROOT/dist"
  cp "$BIN_SOURCE" "$BUILD_OUTPUT"
  chmod +x "$BUILD_OUTPUT"
  echo -e "  ${YELLOW}⚠${NC}  Virtual environment detected"
  echo -e "  ${YELLOW}⚠${NC}  Global link skipped"
  echo -e "  ${GREEN}✓${NC}  Binary copied to ${DIM}$BUILD_OUTPUT${NC}"
  echo ""
  echo -e "  ${DIM}  To use spak command, add to PATH or run:${NC}"
  echo -e "  ${DIM}  export PATH=\"\$PATH:$PROJECT_ROOT/dist\"${NC}"
else
  # Normal environment: create symlink
  if [ -L "$BIN_TARGET" ] || [ ! -e "$BIN_TARGET" ]; then
    ln -sf "$BIN_SOURCE" "$BIN_TARGET"
    echo -e "  ${GREEN}✓${NC}  Global command registered: ${DIM}spak${NC}"
  else
    echo -e "  ${YELLOW}⚠${NC}  ${DIM}$BIN_TARGET${NC} exists and is not a symlink"
    echo -e "  ${YELLOW}⚠${NC}  Skipping link, you may need to manually update it"
  fi
fi

# Done
echo ""
echo -e "  ${GREEN}◇${NC}  ${BOLD}Build complete${NC}"
echo ""
