# Spak ✨

> Un framework de projet multi-services basé sur Koishi

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Qu'est-ce que Spak ?

**Spak** est un **framework de projet multi-services** construit sur [Koishi](https://koishi.chat/). Il offre une manière structurée d'organiser des applications basées sur des plugins avec un support intégré pour la gestion de configuration, l'internationalisation, les outils CLI et l'orchestration de services.

Spak utilise **TypeScript** avec une architecture **pnpm monorepo**.

---

## Paquets

| Paquet | Description |
|--------|-------------|
| `@spakjs/core` 🧠 | Cœur : commandes, middleware, i18n, permissions, schémas |
| `@spakjs/cli` 🎮 | Point d'entrée CLI : `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Chargeur de configuration, support YAML/JSON, fichiers env |
| `@spakjs/config` ⚙️ | Gestionnaire de configuration central, sauvegarde dans `~/.spak/config.json` |
| `@spakjs/locales' 🌐 | Système de traduction basé sur des fichiers yml |
| `@spakjs/ccmd` ⌨️ | Commandes de configuration : `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC : bac à sable, surveillance, vérification des plugins |
| `@spakjs/usefor` 🧰 | Fonctions utilitaires : observation, interpolation de chaînes |
| `@spakjs/i18n-utils' 🌍 | Arborescence des locales et utilitaires de repli |

## Plugins

| Plugin | Description |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | Service serveur et routage |
| `@spakjs/plugin-http' 🌐 | Client HTTP et WebSocket |
| `@spakjs/plugin-hmr` 🔥 | Remplacement à chaud de modules |
| `@spakjs/plugin-daemon` 👻 | Démon d'arrière-plan |

---

## Démarrage rapide

### Prérequis

- Node.js >= 18
- pnpm >= 10

### Installation

```bash
pnpm install
pnpm build
```

### Configuration

Créez **spak.config.yml** :

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Lancement

```bash
spak serve
spak serve ./spak.config.yml
```

### Commandes CLI

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Documentation

- [English](README.md)
- [中文](README.zh.md)

---

## Licence

MIT License. Copyright © Spak Team
