# Spak 喵～ ✨

> 一个基于 Koishi 的多文件服务项目框架的说！

> **English**: [README.md](README.md)

---

## 呜喵～这是什么呀？(=ↀωↀ=)

**Spak** 是一个基于 [Koishi](https://koishi.chat/) 的**多文件服务项目框架**喵！它帮你把插件应用组织得井井有条，内置了配置管理、国际化、CLI 工具和服务编排的说！

咱用的是 **TypeScript** + **pnpm monorepo** 架构喵～

---

## 包包列表

| 包包名 | 是干什么的喵～ |
|--------|--------------|
| `@spakjs/core` 🧠 | 大脑核心的说！命令、中间件、i18n、权限、Schema 都在这里～ |
| `@spakjs/cli` 🎮 | CLI 入口：`spak serve`、`spak config`、`spak cpc` |
| `@spakjs/loader` 📂 | 配置加载器，支持 YAML/JSON，处理 env 文件和插件解析 |
| `@spakjs/config` ⚙️ | 配置管理器，存储到 `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | 翻译系统，使用 yml 格式的 locale 文件 |
| `@spakjs/ccmd` ⌨️ | 配置命令：`spak config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC（插件检查集合）：沙箱、监控、插件检查 |
| `@spakjs/usefor` 🧰 | 工具箱：观察者、字符串插值、杂项小工具 |
| `@spakjs/i18n-utils` 🌍 | Locale 树和回退工具 |

## 插件们

| 插件名 | 说明 |
|--------|------|
| `@spakjs/plugin-server` 🖥️ | 服务器服务和路由 |
| `@spakjs/plugin-http` 🌐 | HTTP 和 WebSocket 客户端 |
| `@spakjs/plugin-hmr` 🔥 | 热模块替换，开发用喵 |
| `@spakjs/plugin-daemon` 👻 | 后台守护进程 |

---

## 快速开始喵！(>ω<)ノ

### 需要准备

- Node.js >= 18
- pnpm >= 10

### 安装

```bash
pnpm install

# 构建所有包包
pnpm build
```

### 配置文件

创建 **spak.config.yml**：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 启动！(=ↀωↀ=)✧

```bash
# 启动应用
spak serve

# 或者指定配置文件
spak serve ./spak.config.yml
```

### CLI 命令

```bash
# 配置管理
spak config get <key>
spak config set <key> <value>
spak config list

# 插件检查和监控
spak cpc check
spak cpc status
```

---

## 项目结构

```
spak/
├── packages/        # 核心包喵！
│   ├── core/        # 框架核心
│   ├── spak-cli/    # CLI 入口
│   ├── loader/      # 配置加载器
│   ├── config/      # 配置管理器
│   ├── locales/     # 翻译系统
│   ├── usefor/      # 工具箱
│   ├── ccmd/        # 配置命令
│   ├── cpc/         # 插件检查系统
│   └── i18n-utils/  # 国际化工具
├── plugins/         # 插件们喵～
│   ├── server/
│   ├── http/
│   ├── hmr/
│   └── daemon/
└── spak.config.yml
```

---

## 📖 多语言文档

| 语言 | 文件 |
|------|------|
| 🇬🇧 English | [README.md](README.md) |
| 🇯🇵 日本語 | [README.ja.md](README.ja.md) |
| 🇰🇷 한국어 | [README.ko.md](README.ko.md) |
| 🇷🇺 Русский | [README.ru.md](README.ru.md) |
| 🇫🇷 Français | [README.fr.md](README.fr.md) |
| 🇪🇸 Español | [README.es.md](README.es.md) |
| 🇩🇪 Deutsch | [README.de.md](README.de.md) |
| 🇸🇦 العربية | [README.ar.md](README.ar.md) |
| 🇹🇿 བོད་སྐད། | [README.bo.md](README.bo.md) |
| 🪐 火星文 | [README.mars.md](README.mars.md) |
| 🐱 喵星人语 | [README.cat.md](README.cat.md) |
| 🌀 胡言乱语 | [README.gibber.md](README.gibber.md) |
| 🥟 中英混合 | [README.chinglish.md](README.chinglish.md) |
| 🧘 大道理 | [README.philos.md](README.philos.md) |
| 🇹🇼 繁體中文 | [README.hant.md](README.hant.md) |
| 📜 文言文 | [README.classical.md](README.classical.md) |
| 😂 梗版 | [README.meme.md](README.meme.md) |

---

## 许可证

MIT License. Copyright © Spak Team

欢迎任何形式的贡献——bug 反馈、功能建议、代码贡献都欢迎喵～(>ω<)ﾉ☆
