# Spak Changelog ✨

> Every step of growth is recorded here! (｡>ω<｡)

> **中文版**: [CHANGELOG.zh.md](CHANGELOG.zh.md)

---

## [0.0.3] — 2026-07-25 🐱

### ✨ Features
- Initial project structure!
- Core package `@spakjs/core` completed
- CLI tool `@spakjs/cli` is now functional
- Config loader `@spakjs/loader` supports YAML/JSON reading
- Utility package `@spakjs/utils` with handy tools
- Internationalization utilities `@spakjs/i18n-utils` ready

### 🖥️ Plugins
- `@spakjs/plugin-server` server service plugin
- `@spakjs/plugin-http` HTTP related plugin
- `@spakjs/plugin-hmr` hot reload plugin
- `@spakjs/plugin-common` common plugin collection

### 🏗️ Engineering
- pnpm monorepo architecture
- TypeScript strict mode configuration
- MIT open source license
- Cat-style README launched!

---

> Meow～ Previous versions haven't been recorded yet～ Will make up for it next time! (*>ω<*)ﾉ
