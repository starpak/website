# སྤཀ་ ✨

> Koishi ལ་གཞི་བཅོལ་བའི་ མང་སེབ་ཞབས་ཞུའི་རྩ་གཞིའི་གྲུབ་སྟངས།

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## སྤཀ་ཞེས་པ་གང་ཡིན།

**སྤཀ་** ནི་ [Koishi](https://koishi.chat/) ལ་གཞི་བཅོལ་བའི་ **མང་སེབ་ཞབས་ཞུའི་རྩ་གཞིའི་གྲུབ་སྟངས་** ཞིག་ཡིན། དེས་ ཆ་འཕྲིན་དོ་དམ། རྒྱལ་སྤྱིའི་སྤྱོད་ཡུལ། CLI ལག་ཆ། ཞབས་ཞུའི་སྒྲིག་སྦྱོར་བཅས་ཀྱི་རྒྱབ་སྐྱོར་ལྡན་པའི་ ཆ་འཕྲིན་གཞི་བཅོལ་གྱི་སྦྱོར་བར་རྩ་འཛུགས་ཀྱི་ཐབས་ལམ་ཞིག་སྤྲོད།

སྤཀ་ ནི་ **TypeScript** དང་ **pnpm monorepo** གྱི་ཐོག་ནས་བེད་སྤྱོད་བྱེད།

---

## ཆ་ཤས་སྒྲིལ་བ།

| ཆ་ཤས། | ངོ་སྤྲོད། |
|---------|-------------|
| `@spakjs/core` 🧠 | སྙིང་པོ། བཀའ་སྒྲོམ། middleware, i18n, དབང་ཆ། |
| `@spakjs/cli` 🎮 | CLI ལྟེ་གནས། `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | ཆ་འཕྲིན་འདྲེན་པ། YAML/JSON དང་ env ཡིག་ཚགས། |
| `@spakjs/config` ⚙️ | ཆ་འཕྲིན་དོ་དམ་པ། `~/.spak/config.json` ལ་ཉར། |
| `@spakjs/locales` 🌐 | yml ཡིག་ཚགས་ཀྱི་བསྒྱུར་ཡིག་མ་ལག |
| `@spakjs/ccmd` ⌨️ | ཆ་འཕྲིན་བཀའ་སྒྲོམ། `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: བྱེ་ཕུང་སྒྲོམ། ལྟ་སྐུལ། ཆ་འཕྲིན་ཞིབ་བཤེར། |
| `@spakjs/usefor` 🧰 | གཞན་ཕན་བྱེད་ལས། |
| `@spakjs/i18n-utils` 🌍 | Locale ཤིང་དང་ fallback བྱེད་ཆས། |

## ཆ་འཕྲིན།

| ཆ་འཕྲིན། | ངོ་སྤྲོད། |
|------------|-------------|
| `@spakjs/plugin-server` 🖥️ | ཞབས་ཞུ་དང་ལམ་བཀར། |
| `@spakjs/plugin-http` 🌐 | HTTP དང་ WebSocket མཁོ་སྤྲོད། |
| `@spakjs/plugin-hmr` 🔥 | Hot Module Replacement |
| `@spakjs/plugin-daemon` 👻 | རྒྱབ་ལྗོངས་སྤྱོད་པ། |

---

## མྱུར་འགོ་ཚུགས།

### དགོས་མཁོ།

- Node.js >= 18
- pnpm >= 10

### འཛུགས་སྒྲིག

```bash
pnpm install
pnpm build
```

### ཆ་འཕྲིན་སྒྲིག་བཀོད།

**spak.config.yml** བཟོ།

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### འགོ་ཚུགས།

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI བཀའ་སྒྲོམ།

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 ཡིག་ཆ།

- [English](README.md)
- [中文](README.zh.md)

---

## ཆོག་མཆན།

MIT License. Copyright © Spak Team
