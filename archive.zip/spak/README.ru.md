# Spak ✨

> Фреймворк для многопроектных сервисов на основе Koishi

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Что такое Spak?

**Spak** — это **фреймворк для многопроектных сервисов**, построенный на [Koishi](https://koishi.chat/). Он предоставляет структурированный способ организации плагин-ориентированных приложений со встроенной поддержкой управления конфигурацией, интернационализации, CLI-инструментов и оркестрации сервисов.

Spak использует **TypeScript** с архитектурой **pnpm monorepo**.

---

## Пакеты

| Пакет | Описание |
|-------|----------|
| `@spakjs/core` 🧠 | Ядро: команды, middleware, i18n, права, схемы |
| `@spakjs/cli` 🎮 | CLI: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Загрузчик конфигов, YAML/JSON, env-файлы |
| `@spakjs/config` ⚙️ | Менеджер конфигурации, сохраняет в `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | Система перевода на основе yml-файлов |
| `@spakjs/ccmd` ⌨️ | Команды конфигурации: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: песочница, мониторинг, проверка плагинов |
| `@spakjs/usefor` 🧰 | Утилиты: наблюдение, интерполяция строк |
| `@spakjs/i18n-utils` 🌍 | Дерево локалей и утилиты fallback |

## Плагины

| Плагин | Описание |
|--------|----------|
| `@spakjs/plugin-server` 🖥️ | Сервер и маршрутизация |
| `@spakjs/plugin-http` 🌐 | HTTP и WebSocket клиент |
| `@spakjs/plugin-hmr` 🔥 | Горячая замена модулей |
| `@spakjs/plugin-daemon` 👻 | Фоновый демон |

---

## Быстрый старт

### Требования

- Node.js >= 18
- pnpm >= 10

### Установка

```bash
pnpm install
pnpm build
```

### Конфигурация

Создайте **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Запуск

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI команды

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Документация

- [English](README.md)
- [中文](README.zh.md)

---

## Лицензия

MIT License. Copyright © Spak Team
