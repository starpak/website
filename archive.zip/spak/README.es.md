# Spak ✨

> Un framework de proyectos multi-servicio basado en Koishi

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## ¿Qué es Spak?

**Spak** es un **framework de proyectos multi-servicio** construido sobre [Koishi](https://koishi.chat/). Proporciona una forma estructurada de organizar aplicaciones basadas en plugins con soporte integrado para gestión de configuración, internacionalización, herramientas CLI y orquestación de servicios.

Spak utiliza **TypeScript** con una arquitectura **pnpm monorepo**.

---

## Paquetes

| Paquete | Descripción |
|---------|-------------|
| `@spakjs/core` 🧠 | Núcleo: comandos, middleware, i18n, permisos, esquemas |
| `@spakjs/cli` 🎮 | Punto de entrada CLI: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Cargador de configuración, soporte YAML/JSON, archivos env |
| `@spakjs/config` ⚙️ | Gestor central de configuración, guarda en `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | Sistema de traducción basado en archivos yml |
| `@spakjs/ccmd` ⌨️ | Comandos de configuración: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: sandbox, monitoreo, verificación de plugins |
| `@spakjs/usefor` 🧰 | Funciones utilitarias: observación, interpolación de cadenas |
| `@spakjs/i18n-utils` 🌍 | Árbol de locales y utilidades de respaldo |

## Plugins

| Plugin | Descripción |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | Servicio de servidor y enrutamiento |
| `@spakjs/plugin-http` 🌐 | Cliente HTTP y WebSocket |
| `@spakjs/plugin-hmr` 🔥 | Reemplazo en caliente de módulos |
| `@spakjs/plugin-daemon` 👻 | Demonio de fondo |

---

## Inicio rápido

### Requisitos

- Node.js >= 18
- pnpm >= 10

### Instalación

```bash
pnpm install
pnpm build
```

### Configuración

Cree **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Ejecución

```bash
spak serve
spak serve ./spak.config.yml
```

### Comandos CLI

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Documentación

- [English](README.md)
- [中文](README.zh.md)

---

## Licencia

MIT License. Copyright © Spak Team
