# Spak ✨

> 一個基於 Koishi 的多文件服務專案框架

> **English**: [README.md](README.md) | **简体中文**: [README.zh.md](README.zh.md)

---

## 什麼是 Spak？

**Spak** 是一個基於 [Koishi](https://koishi.chat/) 的**多文件服務專案框架**。它提供了一個結構化的方式來組織基於插件的應用程式，內建支援配置管理、國際化、CLI 工具和服務編排。

Spak 使用 **TypeScript** 搭配 **pnpm monorepo** 架構。

---

## 套件列表

| 套件 | 說明 |
|------|------|
| `@spakjs/core` 🧠 | 核心：命令、中介層、i18n、權限、結構定義 |
| `@spakjs/cli` 🎮 | CLI 入口：`spak serve`、`spak config`、`spak cpc` |
| `@spakjs/loader` 📂 | 設定載入器，支援 YAML/JSON，處理環境變數檔 |
| `@spakjs/config` ⚙️ | 中央設定管理器，儲存至 `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | 翻譯系統，使用 yml 格式的地區語言檔 |
| `@spakjs/ccmd` ⌨️ | 設定指令：`config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC：沙箱、監控、外掛檢查 |
| `@spakjs/usefor` 🧰 | 工具函式：觀察、字串插值、雜項輔助 |
| `@spakjs/i18n-utils` 🌍 | 地區語言樹與回退工具 |

## 外掛

| 外掛 | 說明 |
|------|------|
| `@spakjs/plugin-server` 🖥️ | 伺服器服務與路由 |
| `@spakjs/plugin-http` 🌐 | HTTP 與 WebSocket 客戶端 |
| `@spakjs/plugin-hmr` 🔥 | 熱模組替換 |
| `@spakjs/plugin-daemon` 👻 | 背景守護程式 |

---

## 快速開始

### 前置需求

- Node.js >= 18
- pnpm >= 10

### 安裝

```bash
pnpm install
pnpm build
```

### 設定

建立 **spak.config.yml**：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 啟動

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI 指令

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 文件

| 語言 | 檔案 |
|------|------|
| 🇬🇧 English | [README.md](README.md) |
| 🇨🇳 简体中文 | [README.zh.md](README.zh.md) |

---

## 授權條款

MIT License. Copyright © Spak Team
