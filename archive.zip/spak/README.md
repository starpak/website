# Spak ✨

> A multi-file service project framework based on Koishi

> **中文版**: [README.zh.md](README.zh.md)

---

## What is Spak?

**Spak** is a **multi-file service project framework** built on top of [Koishi](https://koishi.chat/). It provides a structured way to organize plugin-based applications with built-in support for configuration management, internationalization, CLI tooling, and service orchestration.

Spak uses **TypeScript** with a **pnpm monorepo** architecture.

---

## Packages

| Package | Description |
|---------|-------------|
| `@spakjs/core` 🧠 | Core framework: commands, middleware, i18n, permissions, schemas |
| `@spakjs/cli` 🎮 | CLI entry point: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Config loader, supports YAML/JSON. Handles env files, plugin resolution |
| `@spakjs/config` ⚙️ | Central configuration manager, persists to `~/.spak/config.json` |
| `@spakjs/locales` 🌐 | Translation system with yml-based locale files |
| `@spakjs/ccmd` ⌨️ | Config CLI commands: `spak config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC (Check Plug-in Collection): sandbox, monitoring, plugin checks |
| `@spakjs/usefor` 🧰 | Utility functions: observe, string interpolation, misc helpers |
| `@spakjs/i18n-utils` 🌍 | Locale tree and fallback utilities |

## Plugins

| Plugin | Description |
|--------|-------------|
| `@spakjs/plugin-server` 🖥️ | Server service and routing |
| `@spakjs/plugin-http` 🌐 | HTTP and WebSocket client |
| `@spakjs/plugin-hmr` 🔥 | Hot Module Replacement for development |
| `@spakjs/plugin-daemon` 👻 | Background daemon process |

---

## Quick Start

### Prerequisites

- Node.js >= 18
- pnpm >= 10

### Setup

```bash
pnpm install

# Build all packages
pnpm build
```

### Configuration

Create **spak.config.yml**:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### Run

```bash
# Start the application
spak serve

# Or specify a config file
spak serve ./spak.config.yml
```

### CLI Commands

```bash
# Manage configuration
spak config get <key>
spak config set <key> <value>
spak config list

# Plugin checks and monitoring
spak cpc check
spak cpc status
```

---

## Project Structure

```
spak/
├── packages/        # Core packages
│   ├── core/        # Framework core
│   ├── spak-cli/    # CLI entry
│   ├── loader/      # Config loader
│   ├── config/      # Config manager
│   ├── locales/     # Translation system
│   ├── usefor/      # Utilities
│   ├── ccmd/        # Config commands
│   ├── cpc/         # Plugin check system
│   └── i18n-utils/  # i18n helpers
├── plugins/         # Plugins
│   ├── server/
│   ├── http/
│   ├── hmr/
│   └── daemon/
└── spak.config.yml
```

---

## 📖 Documentation

| Language | File |
|----------|------|
| 🇨🇳 简体中文 | [README.zh.md](README.zh.md) |
| 🇯🇵 日本語 | [README.ja.md](README.ja.md) |
| 🇰🇷 한국어 | [README.ko.md](README.ko.md) |
| 🇷🇺 Русский | [README.ru.md](README.ru.md) |
| 🇫🇷 Français | [README.fr.md](README.fr.md) |
| 🇪🇸 Español | [README.es.md](README.es.md) |
| 🇩🇪 Deutsch | [README.de.md](README.de.md) |
| 🇸🇦 العربية | [README.ar.md](README.ar.md) |
| 🇹🇿 བོད་སྐད། | [README.bo.md](README.bo.md) |
| 🪐 火星文 | [README.mars.md](README.mars.md) |
| 🐱 喵星人语 | [README.cat.md](README.cat.md) |
| 🌀 胡言乱语 | [README.gibber.md](README.gibber.md) |
| 🥟 中英混合 | [README.chinglish.md](README.chinglish.md) |
| 🧘 大道理 | [README.philos.md](README.philos.md) |
| 🇹🇼 繁體中文 | [README.hant.md](README.hant.md) |
| 📜 文言文 | [README.classical.md](README.classical.md) |
| 😂 梗版 | [README.meme.md](README.meme.md) |

---

## License

MIT License. Copyright © Spak Team
