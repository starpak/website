import Loader from '@spakjs/loader'

export { Loader }

export * from '@spakjs/core'
export * from '@spakjs/loader'
export * from './cli/types'
