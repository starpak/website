import { cac } from 'cac'
import { resolve } from 'path'
import { readFileSync } from 'fs'
import { CommandDeclaration } from './types'
import { registerDeclarations, generateCommandHelp } from './registry'
import serveDeclarations from './start'
import configDeclarations from '../commands/config'
import cpcDeclarations from '../commands/cpc'
import { version } from '../../package.json'
const cli = cac('spak').help().version(version)

// Collect all package command declarations
const declarations: CommandDeclaration[] = [
  ...serveDeclarations,
  ...configDeclarations,
  ...cpcDeclarations,
]

registerDeclarations(cli, declarations)

// Intercept --help for subcommands before cac parses them
// Extract full subcommand path from argv (e.g. 'config list', 'cpc check')
const helpIndex = process.argv.findIndex(a => a === '--help' || a === '-h')
if (helpIndex > 0) {
  // Collect all args before --help that aren't flags
  const subArgs: string[] = []
  for (let i = 2; i < helpIndex; i++) {
    const arg = process.argv[i]
    if (!arg.startsWith('-')) subArgs.push(arg)
  }
  if (subArgs.length > 0) {
    const fullPath = subArgs.join(' ')
    const help = generateCommandHelp(fullPath, declarations) || generateCommandHelp(subArgs[0], declarations)
    if (help) {
      console.log(help)
      process.exit(0)
    }
  }
}

const argv = cli.parse()

if (!cli.matchedCommand && !argv.options.help) {
  cli.outputHelp()
}
