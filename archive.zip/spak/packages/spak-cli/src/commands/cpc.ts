import { spawn, ChildProcess } from 'child_process'
import { existsSync, readdirSync, readFileSync, statSync } from 'fs'
import { resolve } from 'path'
import { getConfig, loadConfig } from '@spakjs/config'
import kleur from 'kleur'
import { T } from '@spakjs/i18n'
import { CommandDeclaration } from '@spakjs/util'

// ====== Plugin Check ======
const BUILTIN_PACKAGES_DIR = resolve(process.cwd(), 'packages')
const PLUGINS_DIR = resolve(process.cwd(), 'plugins')

interface PluginCheckResult {
  name: string
  valid: boolean
  reason?: string
}

function checkBuiltinPackage(name: string): PluginCheckResult {
  const pkgDir = resolve(BUILTIN_PACKAGES_DIR, name)
  const requiredDirs = ['src']
  const requiredFiles = ['package.json']

  if (!existsSync(pkgDir)) {
    return { name, valid: false, reason: 'package directory not found' }
  }

  for (const dir of requiredDirs) {
    if (!existsSync(resolve(pkgDir, dir))) {
      return { name, valid: false, reason: `missing directory: ${dir}` }
    }
  }

  for (const file of requiredFiles) {
    if (!existsSync(resolve(pkgDir, file))) {
      return { name, valid: false, reason: `missing file: ${file}` }
    }
  }

  return { name, valid: true }
}

function checkPlugin(name: string): PluginCheckResult {
  const pluginDir = resolve(PLUGINS_DIR, name)

  if (!existsSync(pluginDir)) {
    return { name, valid: false, reason: 'plugin directory not found' }
  }

  const pkgPath = resolve(pluginDir, 'package.json')
  if (!existsSync(pkgPath)) {
    return { name, valid: false, reason: 'package.json not found' }
  }

  let pkg: any
  try {
    pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'))
  } catch {
    return { name, valid: false, reason: 'invalid package.json' }
  }

  // Check main entry
  if (pkg.main && !existsSync(resolve(pluginDir, pkg.main))) {
    return { name, valid: false, reason: `main entry not found: ${pkg.main}` }
  }

  // Check dependencies (warn if missing)
  if (pkg.dependencies) {
    const missingDeps: string[] = []
    for (const dep of Object.keys(pkg.dependencies)) {
      const depPath = resolve(process.cwd(), 'node_modules', dep)
      if (!existsSync(depPath) && !dep.startsWith('@spakjs/')) {
        missingDeps.push(dep)
      }
    }
    if (missingDeps.length > 0) {
      return { name, valid: false, reason: `missing dependencies: ${missingDeps.join(', ')}` }
    }
  }

  return { name, valid: true }
}

function runPluginCheck(): void {
  console.log(kleur.cyan(`\n  ${T('spak.cpc.check.starting')}\n`))

  // Check built-in packages
  const builtinPackages = readdirSync(BUILTIN_PACKAGES_DIR).filter(d => {
    return statSync(resolve(BUILTIN_PACKAGES_DIR, d)).isDirectory()
  })

  let validCount = 0
  let totalCount = 0

  for (const pkg of builtinPackages) {
    totalCount++
    const result = checkBuiltinPackage(pkg)
    if (result.valid) {
      validCount++
      console.log(`  ${kleur.green('✓')} ${kleur.bold(pkg)}: ${result.reason || 'OK'}`)
    } else {
      console.log(`  ${kleur.red('✗')} ${kleur.bold(pkg)}: ${result.reason}`)
    }
  }

  // Check external plugins
  if (existsSync(PLUGINS_DIR)) {
    const plugins = readdirSync(PLUGINS_DIR).filter(d => {
      return statSync(resolve(PLUGINS_DIR, d)).isDirectory()
    })

    for (const plugin of plugins) {
      totalCount++
      const result = checkPlugin(plugin)
      if (result.valid) {
        validCount++
        console.log(`  ${kleur.green('✓')} ${kleur.bold(plugin)}: valid`)
      } else {
        console.log(`  ${kleur.red('✗')} ${kleur.bold(plugin)}: ${result.reason}`)
      }
    }
  }

  console.log(`\n  ${T('spak.cpc.check.complete', { valid: String(validCount), total: String(totalCount) })}\n`)
}

// ====== Sandbox ======
const sandboxProcesses: Map<string, ChildProcess> = new Map()

function isolatePlugin(name: string): void {
  console.log(kleur.cyan(`  ${T('spak.cpc.sandbox.isolating', { name })}`))

  const child = spawn(process.execPath, ['-e', `
    const plugin = ${JSON.stringify(name)};
    console.log('[sandbox] Plugin ' + plugin + ' started');
    process.on('message', (msg) => {
      if (msg === 'shutdown') process.exit(0);
    });
    setInterval(() => {}, 1000);
  `], {
    stdio: ['pipe', 'pipe', 'pipe'],
    detached: true,
  })

  sandboxProcesses.set(name, child)
  console.log(kleur.green(`  ${T('spak.cpc.sandbox.isolated', { name, pid: String(child.pid) })}`))
}

function terminateSandbox(name: string): void {
  const proc = sandboxProcesses.get(name)
  if (proc && proc.pid) {
    try { process.kill(proc.pid) } catch {}
    sandboxProcesses.delete(name)
    console.log(kleur.yellow(`  ${T('spak.cpc.sandbox.terminated', { pid: String(proc.pid) })}`))
  }
}

// ====== SSetPS - Safety Set Protection System ======
let ssetpsInterval: ReturnType<typeof setInterval> | null = null
const MEMORY_LIMIT_MB = 512
const circuitBreakers: Map<string, boolean> = new Map()

function startSSetPS(): void {
  if (ssetpsInterval) return
  console.log(kleur.cyan(`  ${T('spak.cpc.ssetps.monitoring')}`))

  ssetpsInterval = setInterval(() => {
    const memUsage = process.memoryUsage()
    const rssMB = memUsage.rss / 1024 / 1024
    const usagePercent = (rssMB / MEMORY_LIMIT_MB) * 100

    if (usagePercent > 80) {
      console.log(kleur.yellow(`  ${T('spak.cpc.ssetps.memory_warning', { usage: usagePercent.toFixed(1) })}`))

      if (global.gc) {
        const before = process.memoryUsage().rss
        global.gc()
        const after = process.memoryUsage().rss
        const freed = (before - after) / 1024 / 1024
        if (freed > 0) {
          console.log(kleur.green(`  ${T('spak.cpc.ssetps.memory_cleaned', { freed: freed.toFixed(1) })}`))
        }
      }
    }
  }, 10000)
}

function stopSSetPS(): void {
  if (ssetpsInterval) {
    clearInterval(ssetpsInterval)
    ssetpsInterval = null
  }
}

function triggerCircuitBreaker(pluginName: string): void {
  circuitBreakers.set(pluginName, true)
  console.log(kleur.red(`  ${T('spak.cpc.ssetps.circuit_break', { name: pluginName })}`))
  console.log(kleur.red(`  ${T('spak.cpc.ssetps.circuit_open', { name: pluginName })}`))
}

function restoreCircuitBreaker(pluginName: string): void {
  circuitBreakers.delete(pluginName)
  console.log(kleur.green(`  ${T('spak.cpc.ssetps.circuit_restored', { name: pluginName })}`))
}

function applyFirewallRule(rule: string): void {
  console.log(kleur.cyan(`  ${T('spak.cpc.ssetps.firewall_rule', { rule })}`))
}

// ====== Test Suite ======
function runTestServe(url: string): void {
  console.log(kleur.cyan(`\n  ${T('spak.cpc.test.serve')}`))
  console.log(kleur.green(`  ${T('spak.cpc.test.serve_running', { url })}`))

  process.env.DEBUG = '*'
  process.env.SPAK_LOG_LEVEL = '3'

  console.log(`  ${kleur.cyan('[DEBUG]')} Debug mode enabled`)
  console.log(`  ${kleur.cyan('[DEBUG]')} Log level: verbose`)
  console.log(`  ${kleur.cyan('[DEBUG]')} Environment: test`)
}

// ====== Export ======
export function isAvailable(): boolean {
  try {
    const config = loadConfig()
    return config.cpc?.enabled === true
  } catch {
    return false
  }
}

export function ensureAvailable(): void {
  if (!isAvailable()) {
    console.log(kleur.red(`\n  ${T('spak.cpc.config.not_available')}\n`))
    process.exit(1)
  }
}

// Main CPC initialization
export function initCPC(config: any): void {
  if (!config?.enabled) return

  console.log(kleur.cyan(`\n  ${T('spak.cpc.title')}\n`))

  if (config.sandbox?.enabled) {
    console.log(`  ${kleur.green('✓')} ${T('spak.cpc.sandbox.enabled')}`)
  }

  if (config.processIsolation?.enabled) {
    console.log(`  ${kleur.green('✓')} ${T('spak.cpc.process_isolation.enabled')}`)
  }

  if (config.ssetps?.enabled !== false) {
    startSSetPS()
    applyFirewallRule('default: allow localhost, deny external')
  }

  runPluginCheck()
}

function testAction(args: Record<string, string>, options: Record<string, any>) {
  const sub = args.command || ''
  if (sub === 'serve') {
    const host = options.host || '0.0.0.0'
    const port = options.port || '4321'
    runTestServe(`http://${host}:${port}`)
    return
  }
  console.log(kleur.cyan(`\n  ${T('spak.cpc.test.starting')}\n`))
  runPluginCheck()
  console.log(`  ${kleur.green('✓')} ${T('spak.cpc.test.complete', { pass: '0', total: '0' })}\n`)
}

function cpcAction(args: Record<string, string>, options: Record<string, any>) {
  ensureAvailable()
  const sub = args.command || ''
  const arg1 = args.name || ''
  const action = args.action || ''

  if (!sub || sub === 'help') {
    console.log(T('spak.cpc.help'))
    return
  }

  switch (sub) {
    case 'check':
      runPluginCheck()
      break
    case 'sandbox':
      if (arg1 === 'stop') {
        if (!action) { console.log(kleur.red(T('spak.cpc.sandbox.usage_stop'))); return }
        terminateSandbox(action)
      } else {
        if (!arg1) { console.log(kleur.red(T('spak.cpc.sandbox.usage_start'))); return }
        isolatePlugin(arg1)
      }
      break
    case 'ssetps':
      startSSetPS()
      break
    case 'circuit':
      if (arg1 === 'restore') {
        if (!action) { console.log(kleur.red(T('spak.cpc.circuit.usage_restore'))); return }
        restoreCircuitBreaker(action)
      } else {
        if (!arg1) { console.log(kleur.red(T('spak.cpc.circuit.usage_trigger'))); return }
        triggerCircuitBreaker(arg1)
      }
      break
    case 'status':
      console.log(kleur.cyan(`\n  ${T('spak.cpc.title')}`))
      console.log(`  ${kleur.bold(T('spak.cpc.status.sandbox'))} ${sandboxProcesses.size}`)
      console.log(`  ${kleur.bold(T('spak.cpc.status.circuit_breakers'))} ${circuitBreakers.size}`)
      console.log(`  ${kleur.bold(T('spak.cpc.status.ssetps'))} ${ssetpsInterval ? T('spak.cpc.status.active') : T('spak.cpc.status.inactive')}`)
      console.log(`  ${kleur.bold(T('spak.cpc.status.memory'))} ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB\n`)
      break
    default:
      console.log(kleur.red(T('spak.cpc.status.unknown', { sub })))
  }
}

const cpcDeclarations: CommandDeclaration[] = [
  {
    command: 'test',
    description: 'Run CPC test suite',
    action: testAction,
  },
  {
    command: 'cpc',
    description: 'Check Plug-in Collection commands',
    args: [
      { name: 'command', description: 'Subcommand: check, sandbox, ssetps, circuit, status', required: false },
      { name: 'name', description: 'Plugin name argument', required: false },
      { name: 'action', description: 'Sub-action argument', required: false },
    ],
    action: cpcAction,
  },
  {
    command: 'cpc check',
    description: 'Check all plugins and built-in packages',
    action: () => { ensureAvailable(); runPluginCheck(); },
  },
  {
    command: 'cpc sandbox',
    description: 'Isolate a plugin in sandbox',
    args: [{ name: 'name', description: 'Plugin name', required: true }],
    action: (args) => { ensureAvailable(); isolatePlugin(args.name); },
  },
  {
    command: 'cpc ssetps',
    description: 'Start SSetPS monitoring',
    action: () => { ensureAvailable(); startSSetPS(); },
  },
  {
    command: 'cpc circuit',
    description: 'Trigger circuit breaker for a plugin',
    args: [{ name: 'name', description: 'Plugin name', required: true }],
    action: (args) => { ensureAvailable(); triggerCircuitBreaker(args.name); },
  },
  {
    command: 'cpc status',
    description: 'Show CPC status',
    action: () => { ensureAvailable(); cpcAction({ command: 'status', name: '', action: '' }, {}); },
  },
]

export default cpcDeclarations
