#!/usr/bin/env node
require('./lib/cli/index.js')
