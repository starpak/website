import { defineProperty, Promisify, Time } from 'cosmokit'
import { Schema } from 'cordis'
import { GetEvents, Parameters, ReturnType, ThisType } from 'cordis'
import * as cordis from 'cordis'
import { Computed, FilterService } from './filter'
import { Commander, Command } from './command'
import { I18n } from './i18n'
import { Processor } from './middleware'
import { Permissions } from './permission'
import { SchemaService } from './schema'

export type EffectScope = cordis.EffectScope<Context>
export type ForkScope = cordis.ForkScope<Context>
export type MainScope = cordis.MainScope<Context>

export { Logger, Schema } from 'cordis'
export { h, Fragment } from '@spakjs/message'

export { resolveConfig } from 'cordis'

export type { Disposable, ScopeStatus, Plugin } from 'cordis'

declare module 'cordis' {
  namespace Plugin {
    interface Object {
      filter?: boolean
    }
  }
}

export interface EnvData {}

type OmitSubstring<S extends string, T extends string> = S extends `${infer L}${T}${infer R}` ? `${L}${R}` : never
type BeforeEventName = OmitSubstring<keyof Events & string, 'before-'>
type BeforeEventMap = { [E in keyof Events & string as OmitSubstring<E, 'before-'>]: Events[E] }

export interface Events<C extends Context = Context> extends cordis.Events<C> {}

export interface Context {
  [Context.events]: Events<this>
  spak: Spak
  $processor: Processor
  $filter: FilterService
  $commander: Commander
}

export class Context extends cordis.Context {
  static shadow = Symbol.for('session.shadow')

  constructor(config: Context.Config = {}) {
    super(config)
    this.mixin('$processor' as any, ['match', 'middleware'] as any)
    this.mixin('$filter' as any, [
      'any', 'never', 'union', 'intersect', 'exclude',
    ] as any)
    this.mixin('$commander' as any, ['command'] as any)
    this.provide('$filter', new FilterService(this), true)
    this.provide('schema', new SchemaService(this), true)
    this.provide('$processor', new Processor(this), true)
    this.provide('i18n', new I18n(this, this.config.i18n), true)
    this.provide('permissions', new Permissions(this), true)
    this.provide('$commander', new Commander(this, this.config), true)
    this.plugin(Spak, this.config)
  }

  /** @deprecated use `ctx.root` instead */
  get app() {
    return this.root
  }

  /* eslint-disable max-len */
  /** @deprecated */
  waterfall<K extends keyof GetEvents<this>>(name: K, ...args: Parameters<GetEvents<this>[K]>): Promisify<ReturnType<GetEvents<this>[K]>>
  waterfall<K extends keyof GetEvents<this>>(thisArg: ThisType<GetEvents<this>[K]>, name: K, ...args: Parameters<GetEvents<this>[K]>): Promisify<ReturnType<GetEvents<this>[K]>>
  async waterfall(...args: [any, ...any[]]) {
    const thisArg = typeof args[0] === 'object' || typeof args[0] === 'function' ? args.shift() : null
    const name = args.shift()
    for (const hook of this.lifecycle.filterHooks(this.lifecycle._hooks[name] || [], thisArg)) {
      const result = await hook.callback.apply(thisArg, args)
      args[0] = result
    }
    return args[0]
  }

  /** @deprecated */
  chain<K extends keyof GetEvents<this>>(name: K, ...args: Parameters<GetEvents<this>[K]>): ReturnType<GetEvents<this>[K]>
  chain<K extends keyof GetEvents<this>>(thisArg: ThisType<GetEvents<this>[K]>, name: K, ...args: Parameters<GetEvents<this>[K]>): ReturnType<GetEvents<this>[K]>
  chain(...args: [any, ...any[]]) {
    const thisArg = typeof args[0] === 'object' || typeof args[0] === 'function' ? args.shift() : null
    const name = args.shift()
    for (const hook of this.lifecycle.filterHooks(this.lifecycle._hooks[name] || [], thisArg)) {
      const result = hook.callback.apply(thisArg, args)
      args[0] = result
    }
    return args[0]
  }
  /* eslint-enable max-len */

  before<K extends BeforeEventName>(name: K, listener: BeforeEventMap[K], append = false) {
    const seg = (name as string).split('/')
    seg[seg.length - 1] = 'before-' + seg[seg.length - 1]
    return this.on(seg.join('/') as any, listener, !append)
  }
}

export default class Spak extends cordis.Service<Context.Config, Context> {
  constructor(ctx: Context, public config: Context.Config) {
    super(ctx, 'spak', true)
  }
}

export namespace Context {
  export interface Config extends Config.Basic, Config.Advanced {
    i18n?: I18n.Config
  }

  export const Config = Schema.intersect([
    Schema.object({}),
  ]) as Config.Static

  export namespace Config {
    export interface Basic extends Commander.Config {
    }

    export interface Advanced {
      maxListeners?: number
    }

    export interface Static extends Schema<Config> {
      Basic: Schema<Basic>
      I18n: Schema<I18n>
      Advanced: Schema<Advanced>
    }
  }
}

defineProperty(Context.Config, 'Basic', Schema.object({
}).description('Basic settings'))

defineProperty(Context.Config, 'I18n', I18n.Config)

defineProperty(Context.Config, 'Advanced', Schema.object({
  maxListeners: Schema.natural().default(64).description('Maximum number of listeners per type. Exceeding this is considered a memory leak.'),
}).description('Advanced settings'))

Context.Config.list.push(Context.Config.Basic)
Context.Config.list.push(Schema.object({
  i18n: I18n.Config,
}))
Context.Config.list.push(Context.Config.Advanced)

export abstract class Service<T = any, C extends Context = Context> extends cordis.Service<T, C> {
  [cordis.Service.setup]() {
    this.ctx = new Context() as C
  }
}

// for backward compatibility
export { Context as App }

export function defineConfig(config: Context.Config) {
  return config
}
