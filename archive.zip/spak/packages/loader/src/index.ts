import { Dict, Logger } from '@spakjs/core'
import { promises as fs } from 'fs'
import * as dotenv from 'dotenv'
import ns from 'ns-require'
import Loader, { FullReloadError } from './shared'
import { createRequire } from 'module'

export * from './shared'

const _require = createRequire(__filename)

const logger = new Logger('app')

// Use file extension detection instead of deprecated require.extensions
for (const ext of ['.json', '.yaml', '.yml']) {
  Loader.extensions.add(ext)
}

const initialKeys = Object.getOwnPropertyNames(process.env)

export default class NodeLoader extends Loader {
  public scope: ns.Scope
  public localKeys: string[] = []
  public exitOnReload = true

  async init(filename?: string) {
    await super.init(filename)
    this.scope = ns({
      namespace: 'spakjs',
      prefix: 'plugin',
      official: 'spakjs',
      dirname: this.baseDir,
    })
  }

  async readConfig(initial = false) {
    // remove local env variables
    for (const key of this.localKeys) {
      delete process.env[key]
    }

    // load env files
    const parsed = {}
    for (const filename of this.envFiles) {
      try {
        const raw = await fs.readFile(filename, 'utf8')
        Object.assign(parsed, dotenv.parse(raw))
      } catch {}
    }

    // write local env into process.env
    this.localKeys = []
    for (const key in parsed) {
      if (initialKeys.includes(key)) continue
      process.env[key] = parsed[key]
      this.localKeys.push(key)
    }

    return await super.readConfig(initial)
  }

  async import(name: string) {
    try {
      if (!this.cache[name]) {
        try {
          this.cache[name] = _require.resolve(name)
        } catch {
          this.cache[name] = this.scope.resolve(name)
        }
      }
    } catch (err) {
      logger.error(err.message)
      return
    }
    return _require(this.cache[name])
  }

  fullReload(code = Loader.exitCode) {
    const body = JSON.stringify(this.envData)
    const doExit = () => {
      logger.info('trigger full reload')
      if (this.exitOnReload) {
        process.exit(code)
      } else {
        throw new FullReloadError(code)
      }
    }
    if (typeof process.send === 'function') {
      process.send({ type: 'shared', body }, (err: any) => {
        if (err) logger.error('failed to send shared data')
        doExit()
      })
    } else {
      doExit()
    }
  }
}
