# Spak ✨

> Koishi 기반의 다중 파일 서비스 프로젝트 프레임워크

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Spak이란?

**Spak**은 [Koishi](https://koishi.chat/) 위에 구축된 **다중 파일 서비스 프로젝트 프레임워크**입니다. 플러그인 기반 애플리케이션을 구조화된 방식으로 구성할 수 있도록 지원하며, 구성 관리, 국제화, CLI 도구, 서비스 오케스트레이션을 내장하고 있습니다.

Spak은 **TypeScript**와 **pnpm monorepo** 아키텍처를 사용합니다.

---

## 패키지

| 패키지 | 설명 |
|--------|------|
| `@spakjs/core` 🧠 | 코어: 명령어, 미들웨어, i18n, 권한, 스키마 |
| `@spakjs/cli` 🎮 | CLI 진입점: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | 설정 로더, YAML/JSON 지원, env 파일 처리 |
| `@spakjs/config` ⚙️ | 중앙 구성 관리자, `~/.spak/config.json`에 저장 |
| `@spakjs/locales` 🌐 | yml 기반 번역 시스템 |
| `@spakjs/ccmd` ⌨️ | 구성 명령어: `config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC: 샌드박스, 모니터링, 플러그인 검사 |
| `@spakjs/usefor` 🧰 | 유틸리티 함수: 관찰, 문자열 보간 |
| `@spakjs/i18n-utils` 🌍 | 로케일 트리 및 폴백 유틸리티 |

## 플러그인

| 플러그인 | 설명 |
|---------|------|
| `@spakjs/plugin-server` 🖥️ | 서버 서비스 및 라우팅 |
| `@spakjs/plugin-http` 🌐 | HTTP 및 WebSocket 클라이언트 |
| `@spakjs/plugin-hmr` 🔥 | 핫 모듈 리플레이스먼트 |
| `@spakjs/plugin-daemon` 👻 | 백그라운드 데몬 |

---

## 빠른 시작

### 필수 조건

- Node.js >= 18
- pnpm >= 10

### 설치

```bash
pnpm install
pnpm build
```

### 설정

**spak.config.yml** 생성:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 실행

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI 명령어

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 문서

- [English](README.md)
- [中文](README.zh.md)

---

## 라이선스

MIT License. Copyright © Spak Team
