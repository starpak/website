# ㅋㅋㅋ Spak ✨ ٩(◕‿◕｡)۶

> Blorbo schmeegle Koishi frumious bandersnatch! Wibbly wobbly multi-file service frameworky-wamey!

> **Normal**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Gloob gloop squiggle?

**Spak** is a **multi-file service project framework** that goes ding dong on top of [Koishi](https://koishi.chat/). It provides a structurally structured structure for structurizing plugin-based applications with built-in built-ness for configuration configuration, internationalizationationalization, CLI toolification, and service orchestrationationalization!

Spak uses **TypeScript** with a **pnpm monorepo** archi-taco-ture!

🍕 🚀 🦄 ✨ 🎉 🐉 🐱 🎸

---

## 📦 Ding Dong Packages

| Package | Doohickey |
|---------|-----------|
| `@spakjs/core` 🧠 | Core core coreness: commands, middlewares, i18n, permissions, schemer-tastic |
| `@spakjs/cli` 🎮 | CLI entry-diddly-ointy: `spak serve`, `spak config`, `spak cpc` |
| `@spakjs/loader` 📂 | Config loady-thingy, supports YAML/JSON, env files, bloop |
| `@spakjs/config` ⚙️ | Central config management, saves to `~/.spak/config.json` (wow!) |
| `@spakjs/locales` 🌐 | Transla-la-la system with yml files, muy importante! |
| `@spakjs/ccmd` ⌨️ | Config commando: `config get/set/list` pew pew! |
| `@spakjs/cpc` 🔒 | CPC: sandboxie, monitorino, plugin checkeroo |
| `@spakjs/usefor` 🧰 | Utility functions: observe-a-mundo, string interpolation |
| `@spakjs/i18n-utils` 🌍 | Locale tree and fallback boing boing |

## 🎸 Plugins

| Plugin | Dooblydoo |
|--------|-----------|
| `@spakjs/plugin-server` 🖥️ | Server service and routing woot woot |
| `@spakjs/plugin-http` 🌐 | HTTP and WebSocket client, zap! |
| `@spakjs/plugin-hmr` 🔥 | Hot Module Replacement, it's getting hot in here! |
| `@spakjs/plugin-daemon` 👻 | Background daemon, oooOOOoo spooky! |

---

## 🚀 Quick Start! WOOO!

### Prerequisites... or whatever

- Node.js >= 18 (or 42, whatever works)
- pnpm >= 10 (or 11 if you're feeling adventurous)

### Setup witz

```bash
pnpm install
pnpm build
```

### Configutation time!

Create **spak.config.yml** like a boss:

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### GO GO GO!

```bash
spak serve
spak serve ./spak.config.yml
```

### Commandos!

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 Readme-schmeadme

| Language | File |
|----------|------|
| 😎 Normal | [README.md](README.md) |
| 🐉 Chinese | [README.zh.md](README.zh.md) |

---

## Licensey-wensey

MIT License. Copyright © Spak Team

(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ Wow! Such framework! Many plugins! Very TypeScript! Wow! ✧ﾟ･: *ヽ(◕ヮ◕ヽ)
