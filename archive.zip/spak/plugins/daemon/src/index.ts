import { Context, Logger, Schema } from '@spakjs/core'
import { resolve } from 'path'
import { writeFile, unlink, readFile } from 'fs/promises'
import { existsSync, openSync, writeSync } from 'fs'
import { T } from '@spakjs/i18n'

const logger = new Logger('daemon')
const PID_FILE = '.spak.pid'

export const name = 'daemon'

export interface Config {
  enabled: boolean
  logFile: string
}

export const Config: Schema<Config> = Schema.object({
  enabled: Schema.boolean().default(true).description('Enable daemon mode.'),
  logFile: Schema.string().default('spak.log').description('Log file path when running in background.'),
})

export async function apply(ctx: Context, config: Config) {
  if (!config.enabled) return

  // Daemonize the current process
  // Execute after all plugins are loaded via ctx.on('ready')
  ctx.on('ready', async () => {
    // Small delay to ensure all plugins are ready
    await new Promise(resolve => setTimeout(resolve, 100))

    const pid = process.pid
    const logFile = resolve(process.cwd(), config.logFile)

    logger.info(T('spak.daemon.starting'))

    // Save PID to file
    await writeFile(PID_FILE, String(pid), 'utf8')

    // Redirect stdout/stderr to log file
    const stdoutFd = openSync(logFile, 'a')
    const stderrFd = openSync(logFile, 'a')
    
    process.stdout.write = (chunk: any) => {
      writeSync(stdoutFd, String(chunk))
      return true
    }
    process.stderr.write = (chunk: any) => {
      writeSync(stderrFd, String(chunk))
      return true
    }
    
    // Disconnect from terminal
    if (process.stdin.isTTY) {
      process.stdin.unref()
    }
    if (process.stdout.isTTY) {
      // Output final message to original terminal
      console.log(`\n${new Date().toLocaleString()} - ${T('spak.daemon.moved', { pid: String(pid) })}`)
    }
    
    // Detach from parent process group
    process.on('SIGHUP', () => {
      // Ignore SIGHUP to prevent being killed when terminal closes
    })
    
    // Unref stdio to allow process to run independently
    if (process.stdin.isTTY) process.stdin.setRawMode(false)
    process.stdout.unref?.()
    process.stderr.unref?.()
    
    logger.info(T('spak.daemon.running', { pid: String(pid), log: logFile }))
  })
}
