# Spak ✨ — 这™都是梗

> 我绷不绷得住？你先别管，反正五行相克原理告诉我——**金克木，木克土，土克水，水克火，火克Spak**（啊这个不克）
>
> **人类语言**: [README.md](README.md) | **中华娘**（？）: [README.zh.md](README.zh.md)

---

## 三崩演义——开篇话

话说天下大势，**分久必合，合久必崩**。

咱就是说，**你看我绷不绷得住**？反正看到 Spak 这框架我是**绷不住了**——太好用了属于是。这框架要搁三国里头，那就不是三崩演义了，那是**一统天下**啊！

Spak 是一个基于 [Koishi](https://koishi.chat/) 的 **multi-file service framework**。啊？你问我什么是 multi-file？就是很多 file 嘛，这你都不懂？**6**

咱就是说，这框架一整个拿捏住了：配置管理、国际化、CLI、服务编排——**该有的都有，不该有的也有**，主打一个陪伴。

Spak 用 **TypeScript** 写的，**pnpm monorepo** 架构。**泰酷辣！** 🔥

---

## 家人们，看看这些包

### 🔥 火系（主打一个热）

| 包名 | 家人们谁懂啊 |
|------|-------------|
| `@spakjs/core` 🧠 | **大脑门儿**：命令、中间件、i18n、权限、schema，主打一个全能 |

### 💧 水系（主打一个深）

| 包名 | 家人们谁懂啊 |
|------|-------------|
| `@spakjs/config` ⚙️ | **我觉得OK**：存配置到 `~/.spak/config.json`，深藏功与名 |
| `@spakjs/locales` 🌐 | **栓Q**：yml 翻译系统，老铁没毛病，水一样的包容 |

### 🌲 木系（主打一个生长）

| 包名 | 家人们谁懂啊 |
|------|-------------|
| `@spakjs/loader` 📂 | **尊嘟假嘟**？YAML/JSON 都吃，env 也炫，疯狂生长 |
| `@spakjs/ccmd` ⌨️ | **听我说谢谢你**：`config get/set/list`，枝繁叶茂 |
| `@spakjs/usefor` 🧰 | **绝绝子**：工具函数，YYDS，木有啥干不了的 |

### ⛰️ 土系（主打一个稳）

| 包名 | 家人们谁懂啊 |
|------|-------------|
| `@spakjs/cli` 🎮 | **你是我的神**：`spak serve`、`spak config`、`spak cpc`，稳如泰山 |
| `@spakjs/cpc` 🔒 | **属于是**：沙箱、监控、插件检查，**格局打开** |
| `@spakjs/i18n-utils` 🌍 | **爱你老己**：Locale 树和回退工具，主打一个自洽，厚德载物 |

## 插件区——**芜湖起飞** ✈️

| 插件 | 怎么说呢 |
|------|---------|
| `@spakjs/plugin-server` 🖥️ | **高雅人士**：服务器和路由，穿燕尾服的，中华娘の优雅 |
| `@spakjs/plugin-http` 🌐 | **20个黛拉**：HTTP 和 WebSocket 客户端，失误也能变奇迹 |
| `@spakjs/plugin-hmr` 🔥 | **这个就是我呀**：热更新，改完不用重启，主打一个丝滑 |
| `@spakjs/plugin-daemon` 👻 | **进城办事**：后台守护，主打一个低调，你崩我不崩 |

---

## 上手教程——**包教包会，学不会那就是三崩演义** 🐱

### 硬件要求（配置不算高）

- Node.js >= 18（**这我熟**）
- pnpm >= 10（**这我真熟**）

### 开整！

```bash
pnpm install    # 下载，啊对——此乃木生火
pnpm build      # 编译，啊对——此乃火生土
```

### 配置文件——**你小子最好识相**

整个 **spak.config.yml**，**格式错了算我的**，五行相克都克不到你：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 启动！**你看我绷不绷得住**

```bash
spak serve                    # 芜湖，启动！这波我绷住了
spak serve ./spak.config.yml  # 再启动一个，双厨狂喜，彻底绷不住了
```

### 命令大全——**拿来吧你**

```bash
spak config get <key>         # 查，都能查
spak config set <key> <value> # 改，都能改
spak config list              # 看，都能看
spak cpc check                # 检，都能检——三崩演义之五关斩将
spak cpc status               # 瞧，都能瞧——天下大势，尽在掌握
```

---

## 📖 其他语言版本——**格局打开**

| 语言 | 文件 | 备注 |
|------|------|------|
| 🇬🇧 English | [README.md](README.md) | 正经人看的 |
| 🇨🇳 **中华娘** | [README.zh.md](README.zh.md) | 一般正经人看的 |
| 🪐 火星文 | [README.mars.md](README.mars.md) | **这是真不正经** |
| 📜 文言文 | [README.classical.md](README.classical.md) | 绷不住了之古风版 |
| 😂 本梗版 | 你正在看呢 | 从三崩演义到五行相克，全在这儿了 |

---

## 许可证——**关于这个问题，我的态度是**

MIT License. Copyright © Spak Team

**最后的最后——** 这框架你一用，你同学一用，你朋友一用，**属于是直接拿捏了**！主打一个真实，一整个框架界的纯元皇后，**太全面了**！🔥🔥🔥

你说你绷不绷得住？**反正我是绷不住了**！Spak 这个框架，**五行缺的就是你**！

> **爱你老己**，用 Spak 就是爱自己！(=ↀωↀ=)✧
>
> ——《三崩演义》第一回 · **Spak一出天下崩**
