# Spak ✨

> Koishi ベースのマルチファイルサービスプロジェクトフレームワーク

> **English**: [README.md](README.md) | **中文**: [README.zh.md](README.zh.md)

---

## Spak とは？

**Spak** は [Koishi](https://koishi.chat/) 上に構築された**マルチファイルサービスプロジェクトフレームワーク**です。プラグインベースのアプリケーションを構造化された方法で整理し、構成管理、国際化、CLI ツール、サービスオーケストレーションを内蔵サポートしています。

Spak は **TypeScript** と **pnpm monorepo** アーキテクチャを採用しています。

---

## パッケージ

| パッケージ | 説明 |
|-----------|------|
| `@spakjs/core` 🧠 | コア：コマンド、ミドルウェア、i18n、権限、スキーマ |
| `@spakjs/cli` 🎮 | CLI エントリ：`spak serve`、`spak config`、`spak cpc` |
| `@spakjs/loader` 📂 | 設定ローダー、YAML/JSON 対応、env ファイル処理 |
| `@spakjs/config` ⚙️ | 集中設定管理、`~/.spak/config.json` に保存 |
| `@spakjs/locales` 🌐 | yml ベースの翻訳システム |
| `@spakjs/ccmd` ⌨️ | 設定コマンド：`config get/set/list` |
| `@spakjs/cpc` 🔒 | CPC：サンドボックス、監視、プラグインチェック |
| `@spakjs/usefor` 🧰 | ユーティリティ：監視、文字列補間 |
| `@spakjs/i18n-utils` 🌍 | ロケールツリーとフォールバックユーティリティ |

## プラグイン

| プラグイン | 説明 |
|-----------|------|
| `@spakjs/plugin-server` 🖥️ | サーバーサービスとルーティング |
| `@spakjs/plugin-http` 🌐 | HTTP と WebSocket クライアント |
| `@spakjs/plugin-hmr` 🔥 | ホットモジュールリプレースメント |
| `@spakjs/plugin-daemon` 👻 | バックグラウンドデーモン |

---

## クイックスタート

### 前提条件

- Node.js >= 18
- pnpm >= 10

### セットアップ

```bash
pnpm install
pnpm build
```

### 設定

**spak.config.yml** を作成：

```yaml
name: my-spak-app
plugins:
  '@spakjs/plugin-server':
    host: 0.0.0.0
    port: 4321
  '@spakjs/plugin-http': null
  '@spakjs/plugin-daemon':
    enabled: true
    logFile: spak.log
```

### 起動

```bash
spak serve
spak serve ./spak.config.yml
```

### CLI コマンド

```bash
spak config get <key>
spak config set <key> <value>
spak config list
spak cpc check
spak cpc status
```

---

## 📖 ドキュメント

- [English](README.md)
- [中文](README.zh.md)

---

## ライセンス

MIT License. Copyright © Spak Team
